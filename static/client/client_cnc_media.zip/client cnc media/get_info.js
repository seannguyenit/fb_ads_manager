'use strict'

get_data_info()

async function get_data_info() {
    var obj = await get_content_();
    // obj.media = await get_medial_();
    // obj.link = location.href;
    // if (obj) {
    chrome.runtime.sendMessage({ "type": "data", "data": obj });
    window.close();
    // }
}

async function get_content_() {
    var doc = document;
    await remove_href(doc);
    await remove_script(doc);
    await change_src_image(doc);
    var title = doc.title;
    var body_ = await get_main_intelligent(doc);
    return { title: title, content: body_ };
}

async function get_main_intelligent(doc) {
    var select_content_located = doc.body.querySelector('article');
    if (!select_content_located) {
        select_content_located = doc.body.querySelector('precontent')
    }
    if (!select_content_located) {
        select_content_located = document.body.querySelector('[class=ArticleContent]')
    }
    await remove_head(select_content_located);
    //&amp;
    return select_content_located.innerHTML.replaceAll('&nbsp;', ' ').replaceAll('&amp;', ' ').replaceAll('&lt;', ' ');
}

async function remove_href(element) {
    element.querySelectorAll('a').forEach(item => {
        item.removeAttribute("href");
    });
}

async function remove_script(element) {
    element.querySelectorAll('script').forEach(item => {
        item.parentNode.removeChild(item)
    });
}

async function remove_head(element) {
    element.querySelectorAll('header').forEach(item => {
        item.parentNode.removeChild(item)
    });
    element.querySelectorAll('nav').forEach(item => {
        item.parentNode.removeChild(item)
    });
    element.querySelectorAll('footer').forEach(item => {
        item.parentNode.removeChild(item)
    });
}
async function change_src_image(element) {
    element.querySelectorAll('img').forEach(item => {
        if (!item.src.includes('http')) {
            for (let index = 0; index < item.attributes.length; index++) {
                var att = item.attributes[index].nodeValue;
                if (att.includes('http')) {
                    item.src = att;
                    break;
                }
            }
        }
        // if(item.dataset.original||item.dataset.src){
        //     item.src = (item.dataset.original||item.dataset.src);
        // }
    });
}
