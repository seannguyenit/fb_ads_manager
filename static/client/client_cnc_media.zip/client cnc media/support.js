let cr_index_running = -1;

run_();


async function run_() {
    await clone_element(document.getElementById('sp_ex'));
    // console.log('ok go')
    document.getElementById('sp_ex').addEventListener('click', () => {
        sp_content_by_plugin()
    });
}

// document.getElementById('sp_ex').onclick = sp_content_by_plugin;

function sp_content_by_plugin() {
    var url = document.getElementById('sp_ex').dataset.url;
    var index = document.getElementById('sp_ex').dataset.index;
    if (cr_index_running == parseInt(index)) {
        return;
    } else {
        cr_index_running = index;
        chrome.runtime.sendMessage({ "type": "get_content", "url": url, "index": index });
    }
}



async function clone_element(old_e) {
    if (!old_e) return;
    var new_element = old_e.cloneNode(true);
    await old_e.parentNode.replaceChild(new_element, old_e);
}

chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    try {
        if (request.type == "get_content_rs") {

            var content;
            var rs = request.data;
            // content = res.content;
            content = { title: rs.data.title, content: rs.data.content, index: rs.cr_index };
            console.log(content);
            document.getElementById('sp_ex').dataset.js_data = JSON.stringify(content);
            document.getElementById('sp_ex').dataset.stt = "1";
        }
    } catch (error) {
        console.log(error);
        // sendResponse({ result: "Fail" });
    }
});

// async function set_info(info) {
//     if (!info) return;
//     document.getElementById('input_link').value = info.link;
//     document.getElementById('content_located').value = info.content;

//     var arr_media = info.media;
//     if (!arr_media) return;
//     var par = document.getElementById('media_located');
//     par.innerHTML = '';
//     arr_media.forEach(ele => {
//         var src = ele.src;
//         // src = src.replaceAll('http://localhost:3000/', root_url);
//         par.innerHTML += `<div class="col-md-12 d-flex p-1" style="border-bottom:solid 1px black ;height: 120px;">
//         <div class="col-md-2">
//             <img width="100" height="100" src="${src}" />
//         </div>
//         <div class="col-md-10 text-center">
//             <a target="_blank" href="${src}" style="margin: auto;word-wrap: normal;">${src}</a>
//         </div>
//     </div>`;
//     });
// }

// document.getElementById('get_fb_info').addEventListener('click', async () => {
//     await get_fb_info();
// });


// async function set_fb_img(info) {
//     if (!info) return;
//     document.getElementById('fb_ava').src = info;
// }
// async function get_fb_info() {
//     var url = document.getElementById('link_fb').value;
//     if (url.length == 0) {
//         alert('Vui lòng nhập link !');
//     }
//     call_ex_data('get_fb_info', { url: url });
//     // {viewerID:100067863644324,userVanity:lyn.nguyen.908,userID:100003804766446}
// }

// async function call_ex_data(name, data) {
//     chrome.runtime.sendMessage({ "type": "data", "name": name, "data": data });
// }


// async function delay(delayInms) {
//     return new Promise(resolve => {
//         setTimeout(() => {
//             resolve(2);
//         }, delayInms);
//     });
// }
// async function waitingForNext(time) {
//     // console.log('waiting...')
//     let delayres = await delay(time);
// }