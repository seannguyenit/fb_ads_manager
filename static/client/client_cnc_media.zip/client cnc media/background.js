'use strict'

var waiting_list = [];


// chrome.runtime.onInstalled.addListener((details) => {
//     init_menu();
// });

// chrome.browserAction.onClicked.addListener(function (tab) {

//     //Lấy tin tức
//     run_app(tab);

// });

chrome.tabs.onUpdated.addListener(async (tab_id, change_info, tab) => {
    if (!change_info.url) return;
    //chrome://
    if (change_info.url.includes('chrome://')) return;
    if (change_info.url.includes('ncnmediacontent.com/home/getcontent') || change_info.url.includes('http://localhost:3000/home/getcontent')) {
        console.log('coutns');
        chrome.tabs.executeScript(tab.id, {
            runAt: 'document_end',
            file: 'support.js'
        });
    }
    // if (change_info.url.includes('https://') || change_info.url.includes('http://')) {
    //     try {
    //         chrome.tabs.executeScript(tab.id, {
    //             runAt: 'document_end',
    //             file: 'message_helper.js'
    //         });
    //     } catch (error) {
    //         console.log(error);
    //     }
    // };
});

// function init_menu() {
//     try {
//         var run_app = "ex_run_app";
//         chrome.contextMenus.create({
//             id: run_app,
//             title: "Lấy tin tức",
//             contexts: ["all"]
//         });
//     } catch (error) {
//         console.log(error);
//     }
// }

// chrome.contextMenus.onClicked.addListener((info, tab) => {
//     switch (info.menuItemId) {
//         case "ex_run_app":
//             run_app(info)
//         default:
//             break;
//     }
//     // console.log(info);
// })
// async function run_app(info) {
//     chrome.tabs.executeScript(info.id, {
//         runAt: 'document_end',
//         file: 'get_info.js'
//     });
// }


chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    try {
        switch (request.type) {
            case "get_content":
                var rs = await get_content_from_url(request.url, sender.tab.id, request.index);
                chrome.tabs.sendMessage(sender.tab.id, { type: "get_content_rs", data: rs });

                // if (request.name == 'get_fb_info') {
                //     let url = request.data.url;
                //     let data = await get_id_from_url(url);
                //     if (!data.img) {
                //         prepare_to_get_img_in_open_direct(url, sender.tab.id);
                //     }
                //     chrome.tabs.sendMessage(sender.tab.id, { type: 'fb_info', data: data })
                //     sendResponse({ result: "OK" });
                // } 
                // else if (request.name == 'get_img') {
                //     let data = request.data;
                //     if (waiting_tag_id) {
                //         chrome.tabs.sendMessage(waiting_tag_id, { type: 'fb_img', data: data });
                //     }
                //     chrome.tabs.remove(sender.tab.id);
                // }
                break;
            case "data":
                let data = request.data;
                var index_check = waiting_list.findIndex((f) => { return f.link == sender.tab.url });
                if (index_check > -1) {
                    waiting_list[index_check].data = data;
                }
                break;
            default:
                break;
        }
    } catch (error) {
        console.log(error);
        sendResponse({ result: "Fail" });
    }
});

async function get_content_from_url(url, sender_id, cr_index) {
    var index_check = waiting_list.findIndex((f) => { return f.tab_id == sender_id });
    if (index_check != -1) {
        waiting_list[index_check].link = url;
        waiting_list[index_check].cr_index = cr_index;
        waiting_list[index_check].data = null;
    } else {
        waiting_list.push({ tab_id: sender_id, link: url, cr_index: cr_index, data: null });
    }
    // console.log(waiting_list);
    chrome.tabs.create(
        {
            url: url,
            active: false,
            selected: false
        },
        async function callback(tab) {
            await run_get_info(tab.id);
        }
    );
    var count = 0;
    var rs;
    while ((count < 10) && !rs) {
        let w = await waitingForNext(2000);
        rs = waiting_list.find((f) => { return (f.tab_id == sender_id) }).data;
        count++;
    }
    if (rs) {
        return waiting_list.find((f) => { return (f.tab_id == sender_id) });
    } else {
        return {};
    }
}

async function run_get_info(id) {
    let w = await waitingForNext(1000);
    chrome.tabs.executeScript(id, {
        runAt: 'document_end',
        file: 'get_info.js'
    });
}

// /**
//  * 
//  * @param {content,media,link} data 
//  */
// async function show_data_to_manager(data, send_id) {
//     //get manager tab
//     var manager_ = {};
//     await chrome.tabs.query({ currentWindow: true }, (tabs) => {
//         // manager_ = tabs;
//         manager_ = tabs.find((f) => { return f.url.includes('ncnmediacontent.com/home/getcontent') || f.url.includes('http://localhost:3000/home/getcontent') });
//     });
//     // var c = 0;
//     // while(c < 10 && manager_ == undefined)
//     let w = await waitingForNext(1000);
//     if (!manager_) {
//         chrome.tabs.executeScript(send_id, {
//             runAt: 'document_end',
//             code: `alert('Chưa đăng nhập vào web quản lý !');`
//         });
//     }
//     // console.log(manager_);
//     //send data to manager tab
//     chrome.tabs.sendMessage(manager_.id, { type: 'info', data: data })

// }


// function prepare_to_get_img_in_open_direct(url, tag_id) {
//     waiting_tag_id = tag_id;
//     chrome.tabs.create(
//         {
//             url: url,
//             active: false,
//             selected: false
//         },
//         function callback(tab) {
//             run_get_img(tab.id);
//         }
//     );
// }

// async function run_get_img(id) {
//     let w = await waitingForNext(2000);
//     chrome.tabs.executeScript(id, {
//         runAt: 'document_end',
//         file: 'get_img.js'
//     });
// }


async function delay(delayInms) {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(2);
        }, delayInms);
    });
}
async function waitingForNext(time) {
    // console.log('waiting...')
    let delayres = await delay(time);
}