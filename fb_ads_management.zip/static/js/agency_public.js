'use strict'

async function init_agency_public() {

}


async function agency_register() {
    if (!confirm(`Bạn có chắc chắn muốn đăng ký làm đại lý ?`)) {
        return;
    }
    var cr_u = get_cr_user();
    if (cr_u) {
        await fetch(`/api/agency/${cr_u.id}`, {
            method: 'PUT', // or 'PUT'
        })
            .then(response => response.text())
            .then(r => {
                alert('Đăng ký thành công ! Vui lòng chờ quản trị viên xét duyệt !')
                return r;
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
}